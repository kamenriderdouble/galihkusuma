-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2024 at 05:20 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `galleri`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `admin_telp` varchar(20) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`admin_id`, `admin_name`, `username`, `password`, `admin_telp`, `admin_email`, `admin_address`) VALUES
(11, 'XIRPL', 'XI RPL', '1', '1', 'XIRPL@gmail.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_category`
--

CREATE TABLE `tb_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tb_category`
--

INSERT INTO `tb_category` (`category_id`, `category_name`) VALUES
(30, 'DPIB'),
(31, 'RPL'),
(32, 'TKRO'),
(33, 'TBSM'),
(34, 'PBS'),
(35, 'Animasi');

-- --------------------------------------------------------

--
-- Table structure for table `tb_image`
--

CREATE TABLE `tb_image` (
  `image_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `image_name` varchar(100) NOT NULL,
  `image_description` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `image_status` tinyint(1) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tb_image`
--

INSERT INTO `tb_image` (`image_id`, `category_id`, `category_name`, `admin_id`, `admin_name`, `image_name`, `image_description`, `image`, `image_status`, `date_created`) VALUES
(56, 31, 'RPL', 11, 'XIRPL', 'XI RPL', '<p>Jurusan Rekayasa Perangkat Lunak (RPL) merupakan bidang studi yang mengajarkan dan memperdalam pengembangan perangkat lunak, meliputi pembuatan, pemeliharaan, manajemen organisasi pengembangan perangkat lunak, dan manajemen mutu. Bidang ini berkaitan dengan perangkat lunak komputer, seperti website, aplikasi, game, dan segala sesuatu yang berhubungan dengan pemrograman.</p>\r\n', 'foto1707103117.jpeg', 1, '2024-02-05 03:20:13'),
(57, 30, 'DPIB', 11, 'XIRPL', 'XI DPIB', 'Jurusan DPib Arsitektur (Diploma Pendidikan Informatika dan Arsitektur) merupakan jurusan yang menekankan pada pengembangan kemampuan individu dalam menggunakan teknologi informasi dan arsitektur. Jurusan ini bertujuan untuk menghasilkan lulusan yang memiliki kemampuan dalam mendesain, menganalisis, dan mengimplementasikan sistem informasi dan arsitektur.', 'foto1707103307.jpeg', 1, '2024-02-05 03:21:47'),
(58, 32, 'TKRO', 11, 'XIRPL', 'TKRO', 'Jurusan Teknik Kendaraan Ringan Otomotif Mobil merupakan bidang studi yang fokus pada perawatan, perbaikan, dan perancangan kendaraan otomotif. Program ini menggabungkan berbagai disiplin ilmu, seperti teknik mesin, elektronika, dan ilmu komputer, untuk membekali mahasiswa dengan pengetahuan dan keterampilan dalam sistem otomotif, termasuk performa mesin, sistem drivetrain, suspensi dan kemudi, rem, dan sistem kendali elektronik.', 'foto1707103482.jpeg', 1, '2024-02-05 03:24:42'),
(59, 33, 'TBSM', 11, 'XIRPL', 'XI TBSM', 'Jurusan Teknik Sepeda Motor merupakan bidang studi yang fokus pada perawatan, perbaikan, dan perancangan sepeda motor. Program ini menggabungkan berbagai disiplin ilmu, seperti teknik mesin, elektronika, dan ilmu komputer, untuk membekali mahasiswa dengan pengetahuan dan keterampilan dalam sistem sepeda motor, termasuk performa mesin, sistem drivetrain, suspensi dan kemudi, rem, dan sistem kendali elektronik.', 'foto1707103609.jpeg', 1, '2024-02-05 03:26:49'),
(61, 35, 'Animasi', 11, 'XIRPL', 'ANIMASI', 'Jurusan Animasi merupakan bidang studi yang berfokus pada pembuatan dan produksi konten animasi untuk berbagai media, seperti film, acara televisi, video game, dan website. Program ini menggabungkan berbagai disiplin ilmu, seperti seni, desain, ilmu komputer, dan teknologi, untuk membekali siswa dengan pengetahuan dan keterampilan dalam prinsip-prinsip animasi, teknik animasi 2D dan 3D, bercerita, desain karakter, dan efek visual.', 'foto1707103899.png', 1, '2024-02-05 03:31:39'),
(62, 34, 'PBS', 11, 'XIRPL', 'PBS', 'Jurusan Perbankan Syariah adalah bidang studi yang berfokus pada prinsip dan praktik perbankan dan keuangan Islam. Program ini mencakup berbagai aspek perbankan Islam, termasuk hukum Syariah, manajemen keuangan, akuntansi, dan ekonomi, dengan penekanan pada penerapan prinsip-prinsip tersebut dalam industri perbankan.', 'foto1707104311.jpeg', 1, '2024-02-05 03:38:31'),
(63, 31, 'RPL', 11, 'XIRPL', 'XI RPL2', 'Jurusan Rekayasa Perangkat Lunak (RPL) merupakan bidang studi yang mengajarkan dan memperdalam pengembangan perangkat lunak, meliputi pembuatan, pemeliharaan, manajemen organisasi pengembangan perangkat lunak, dan manajemen mutu. Bidang ini berkaitan dengan perangkat lunak komputer, seperti website, aplikasi, game, dan segala sesuatu yang berhubungan dengan pemrograman.', 'foto1707105255.jpeg', 1, '2024-02-05 03:54:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tb_category`
--
ALTER TABLE `tb_category`
  ADD PRIMARY KEY (`category_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `tb_image`
--
ALTER TABLE `tb_image`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_category`
--
ALTER TABLE `tb_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tb_image`
--
ALTER TABLE `tb_image`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_image`
--
ALTER TABLE `tb_image`
  ADD CONSTRAINT `tb_image_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `tb_admin` (`admin_id`),
  ADD CONSTRAINT `tb_image_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `tb_category` (`category_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
